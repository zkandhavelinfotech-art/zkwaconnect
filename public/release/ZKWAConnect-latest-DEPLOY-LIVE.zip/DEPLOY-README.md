# ZKWAConnect v5.2.0 — Production Deployment Guide (LIVE / PRODUCTION)

This package contains the complete production-ready source code, pre-compiled Next.js production build (`.next`), MySQL database migration scripts, and server configuration files for GoDaddy PaaS / cPanel / Linux VPS.

---

## 🚀 1. GoDaddy PaaS / cPanel Deployment Steps

### Method A: GoDaddy Airo / PaaS (Upload Archive)
1. In GoDaddy PaaS, upload the generated `ZKWAConnect-v6.0.0-DEPLOY-LIVE.zip`.
2. GoDaddy automatically detects `.airo/config.json` and uses `node server.js` as the entry point.
3. The bundle includes the pre-compiled `.next` production build. If missing for any reason, `server.js` features self-healing and builds it automatically.
4. Set environment variables in GoDaddy PaaS Settings (or edit `.env`):
   ```bash
   NODE_ENV="production"
   PORT=3000
   DATABASE_URL="mysql://your_db_user:your_password@localhost:3306/your_db_name"
   NEXT_PUBLIC_APP_URL="https://yourdomain.com"
   NEXTAUTH_SECRET="your_secure_32_character_secret_key"
   ```

### Method B: cPanel "Setup Node.js App"
1. In cPanel ➔ **Setup Node.js App**:
   - **Node.js version:** Select `20.x` or `22.x`
   - **Application mode:** `Production`
   - **Application root:** `/home/username/public_html` or `/home/username/zkwaconnect`
   - **Application startup file:** `app.js` (or `server.js`)
2. **Extract this ZIP** into your application root folder.
3. Click **Run NPM Install** (or in terminal: `npm install --omit=dev`).
4. Click **Restart**!

---

## 🐬 2. MySQL Database Migration & Setup

To create all 50+ tables, foreign keys, indexes, and seed default plans and admin logins:

### Option 1 (1-Click Command via SSH / Terminal):
```bash
npm run db:migrate:mysql
```
This script automatically applies the MySQL schema, generates the Prisma client, pushes all tables, and seeds the default plans, super admin (`admin@zkwaconnect.in`), WABA account, and client logins.

### Option 2 (via phpMyAdmin UI):
1. Open **phpMyAdmin** in your hosting control panel.
2. Select your target MySQL database.
3. Click the **Import** tab.
4. Choose the file: `prisma/schema-mysql.sql` and click **Import** / **Go**.

---

## 🔑 3. Default Initial Logins
- **SaaS Product Admin:** `admin@zkwaconnect.in` / `admin2026!`
- **WABA Root Admin:** `waba@zkandavelinfotech.com` / `waba1234`
- **Customer Client 1 (RTA):** `rta@recruitmentacademy.com` / `rta1234`
- **Customer Client 2 (Smeram):** `smeram@smeramindustries.com` / `smeram1234`
