# ZKWAConnect v6 — Deployment Guide (DEV / LOCAL)

This ZIP contains the complete production-ready source code, database migration scripts, and server configurations for ZKWAConnect v6.

## 1. Quick Server Setup
1. **Extract this ZIP** to your server directory (e.g. `/var/www/zkwaconnect` or GoDaddy `/home/user/zkwaconnect`).
2. **Review .env:** Update the `DATABASE_URL` with your MySQL database credentials.
3. **Import Database Schema:**
   - In phpMyAdmin / MySQL CLI, run:
     ```bash
     mysql -u username -p database_name < prisma/schema-mysql.sql
     ```
4. **Install & Build:**
   ```bash
   npm install --production=false
   npm run build
   ```
5. **Start Application:**
   - Standalone: `npm start`
   - With PM2: `pm2 start ecosystem.config.js --env development`
   - With Docker: `docker-compose up -d`

## 2. Multi-Domain Routing
- **Marketing & Admin Portal:** `zkwaconnect.in` (Port 3000 or unified 3002)
- **Customer WhatsApp Platform:** `app.zkwaconnect.in` (Port 3001 or unified 3002)
- **Public REST API:** `api.zkwaconnect.in` (Port 3002)
