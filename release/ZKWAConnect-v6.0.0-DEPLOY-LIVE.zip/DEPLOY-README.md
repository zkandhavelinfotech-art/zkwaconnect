# ZKWAConnect v6 — Deployment Guide (LIVE / PRODUCTION)

This ZIP contains the complete production-ready source code, database migration scripts, and server configurations for ZKWAConnect v6.

## 1. Quick Server Setup (GoDaddy / cPanel / Shared Hosting)
1. In cPanel **Setup Node.js App**:
   - **Node.js version:** Select 20.x or 22.x
   - **Application mode:** `Production`
   - **Application root:** `/home/username/public_html` or `/home/username/zkwaconnect`
   - **Application startup file:** `app.js` (or `server.js`)
2. **Extract this ZIP** into your Application root directory.
3. Open **phpMyAdmin**, select your MySQL database, and import `prisma/schema-mysql.sql`.
4. In cPanel, click **Run NPM Install** or in terminal run:
   ```bash
   npm install --production=false
   npm run build
   ```
5. Click **Restart App** in cPanel!

## 2. Multi-Domain Routing
- **Marketing & Admin Portal:** `zkwaconnect.in` (Port 3000 or unified 3002)
- **Customer WhatsApp Platform:** `app.zkwaconnect.in` (Port 3001 or unified 3002)
- **Public REST API:** `api.zkwaconnect.in` (Port 3002)
